# OrderService
Simple order service using serverless architecture.
